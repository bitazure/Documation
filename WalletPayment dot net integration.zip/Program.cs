﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WalletPayment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AddWhitelist("BNB", "0x14cfdE42249bddF230B773010e94aBf965254137", -1, "123", "Test", "test@test.com", "9876543210", 100, 0.001);
            //SendWithdrawRequest("BNB", "0x14cfdE42249bddF230B773010e94aBf965254135", 0.001, "123", "Test", "test@test.com", "9876543210");
            //TokenHelper.ValidateToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyZWZlcmVuY2VObyI6IjNmNDczNDA3YjczMTQzNDJhZGFlNzM3MTIyYzRiMGZmIiwidHJhbnNhY3Rpb25JZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMCIsInRyYW5zYWN0aW9uaGFzaCI6IjB4OGJkYmE3ZGY1OGQ3MDEyMjViOWU0NmI0MWVlMDM5MGNmYmY4ZDhmM2YyYjNmMzEwMTM0NWQ2MjhlOWFkMzBlMSIsInN0YXR1cyI6IkFwcHJvdmVkIiwiaWF0IjoxNzMwMjAzODgwLCJleHAiOjE3MzAyMDM5NDB9.4RqzxgaHzaJ9fIW3tM49Z2Vrp8FnIE1KfRJ77xa5MrI");
            //GetDepositUrl("BNB", "0x14cfdE42249bddF230B773010e94aBf965254135", 0.001, "123", "Test", "test@test.com", "9876543210");
        }

        static bool GetDepositUrl(
        string type,
        string address,
        double amount,
        string customerId,
        string customerName,
        string customerEmail,
        string customerPhone
        )
        {
            DepositPayload payload = new DepositPayload()
            {
                Type = type,
                Address = address,
                Amount = amount,
                Email = customerEmail,
                Id = customerId,
                Name = customerName,
                Mobile = customerPhone,
                TxnId = new Guid().ToString(),
                TokenAddress = "",
            };

            string token = TokenHelper.GenerateDepositAuthToken(payload);
            try
            {
                var result = TokenHelper.SendRequest(TokenHelper.DEPOSIT, token);

                foreach (var item in result.Headers)
                {
                    Console.WriteLine($"Header: {item.Key} - {string.Join(",", item.Value)}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        static bool SendWithdrawRequest(
         string type,
         string address,
         double amount,
         string customerId,
         string customerName,
         string customerEmail,
         string customerPhone
         )
        {
            WithdrawPayload payload = new WithdrawPayload()
            {
                Type = type,
                Address = address,
                Amount = amount,
                Email = customerEmail,
                Id = customerId,
                Name = customerName,
                Mobile = customerPhone,
                TxnId = new Guid().ToString(),
                TokenAddress = "",
            };

            string token = TokenHelper.GenerateWithdrawAuthToken(payload);
            try
            {
                var result = TokenHelper.SendRequest(TokenHelper.WITHDRAW, token);
                Console.WriteLine(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        static bool AddWhitelist(
            string type,
            string address,
            int coolingPeriod,
            string customerId,
            string customerName,
            string customerEmail,
            string customerPhone,
            int maxCoins,
            double minCoins
            )
        {
            WhitelistPayload payload = new WhitelistPayload()
            {
                Type = type,
                Address = address,
                CoolingPeriod = coolingPeriod,
                CustomerEmail = customerEmail,
                CustomerId = customerId,
                CustomerName = customerName,
                CustomerPhone = customerPhone,
                MaxCoins = maxCoins,
                MinCoins = minCoins,
            };

            string token = TokenHelper.GenerateWhitelistAuthToken(payload);
            try
            {
                var result = TokenHelper.SendRequest(TokenHelper.WHITELIST, token);
                Console.WriteLine(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }
    }
}
