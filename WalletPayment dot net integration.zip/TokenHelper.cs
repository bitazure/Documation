﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;

namespace WalletPayment
{
    public class WhitelistPayload
    {
        public string Address { get; set; }
        public string Type { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerId { get; set; }
        public double MinCoins { get; set; }
        public double MaxCoins { get; set; }
        public int CoolingPeriod { get; set; }
    }
    public class DepositPayload
    {
        public string TxnId { get; set; }
        public double Amount { get; set; }
        public string Type { get; set; }
        public string Address { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string TokenAddress { get; set; }
    }
    public class WithdrawPayload
    {
        public string TxnId { get; set; }
        public double Amount { get; set; }
        public string Type { get; set; }
        public string Address { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string TokenAddress { get; set; }
    }

    public class ResponsePayload
    {
        public string ReferenceNo { get; set; }
        public string TransactionId { get; set; }
        public string Transactionhash { get; set; }
        public string Status { get; set; }
    }


    public static class TokenHelper
    {
        private static readonly string merchantKey = ConfigurationManager.AppSettings["merchantKey"];
        private static readonly string issuer = ConfigurationManager.AppSettings["issuer"];
        private static readonly string audience = ConfigurationManager.AppSettings["audience"];
        private static readonly string expiryTime = ConfigurationManager.AppSettings["expiryTime"];
        private static readonly string successUrl = ConfigurationManager.AppSettings["successUrl"];
        private static readonly string failureUrl = ConfigurationManager.AppSettings["failureUrl"];
        private static readonly string depositWebhookUrl = ConfigurationManager.AppSettings["depositWebhookUrl"];
        private static readonly string withdrawWebhookUrl = ConfigurationManager.AppSettings["withdrawWebhookUrl"];
        private static readonly string whitelistUrl = ConfigurationManager.AppSettings["whitelistUrl"];
        private static readonly string depositUrl = ConfigurationManager.AppSettings["depositUrl"];
        private static readonly string withdrawUrl = ConfigurationManager.AppSettings["withdrawUrl"];
        private static readonly string tokenAddress = ConfigurationManager.AppSettings["tokenAddress"];

        public static readonly string WHITELIST = "whitelist";
        public static readonly string DEPOSIT = "deposit";
        public static readonly string WITHDRAW = "withdraw";

        public static string GenerateWhitelistAuthToken(WhitelistPayload payload)
        {
            IEnumerable<Claim> claims = new[]
                {
                new Claim("address", payload.Address),
                new Claim("type",payload.Type),
                new Claim("customerName",payload.CustomerName),
                new Claim("customerEmail",payload.CustomerEmail),
                new Claim("customerPhone",payload.CustomerPhone),
                new Claim("customerId",payload.CustomerId),
                new Claim("minCoins",payload.MinCoins.ToString()),
                new Claim("maxCoins",payload.MaxCoins.ToString()),
                new Claim("coolingPeriod",payload.CoolingPeriod.ToString())
            };

            return GenerateToken(claims);
        }

        public static string GenerateDepositAuthToken(DepositPayload payload)
        {
            IEnumerable<Claim> claims = new[]
                {
                new Claim( "txnid", payload.TxnId),
                new Claim( "amount", payload.Amount.ToString()),
                new Claim( "type", payload.Type),
                new Claim( "address", payload.Address),
                new Claim( "tokenAddress", payload.TokenAddress),
                new Claim( "cid", payload.Id),
                new Claim( "name", payload.Name),
                new Claim( "email", payload.Email),
                new Claim( "mobile", payload.Mobile),
                new Claim( "successUrl", successUrl),
                new Claim( "failureUrl", failureUrl),
                new Claim( "webhookUrl", depositWebhookUrl)
            };

            return GenerateToken(claims);
        }

        public static string GenerateWithdrawAuthToken(WithdrawPayload payload)
        {
            IEnumerable<Claim> claims = new[]
                {
                new Claim( "txnid", payload.TxnId),
                new Claim( "amount", payload.Amount.ToString()),
                new Claim( "type", payload.Type),
                new Claim( "address", payload.Address),
                new Claim( "tokenAddress", payload.TokenAddress),
                new Claim( "cid", payload.Id),
                new Claim( "name", payload.Name),
                new Claim( "email", payload.Email),
                new Claim( "mobile", payload.Mobile),
                new Claim( "webhookUrl", withdrawWebhookUrl)
            };

            return GenerateToken(claims);
        }
        static string GenerateToken(IEnumerable<Claim> claims)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(merchantKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToInt32(expiryTime)),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public static ResponsePayload ValidateToken(string authToken)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var validationParameters = GetValidationParameters();
            try
            {
                SecurityToken validatedToken;
                IPrincipal principal = tokenHandler.ValidateToken(authToken, validationParameters, out validatedToken);
                if (principal.Identity != null && principal.Identity.IsAuthenticated)
                {
                    var token = new JwtSecurityTokenHandler().ReadJwtToken(authToken);
                    ResponsePayload response = new ResponsePayload()
                    {
                        ReferenceNo = token.Claims.First(c => c.Type == "referenceNo").Value,
                        Transactionhash = token.Claims.First(c => c.Type == "transactionhash").Value,
                        TransactionId = token.Claims.First(c => c.Type == "transactionId").Value,
                        Status = token.Claims.First(c => c.Type == "status").Value
                    };
                    return response;
                }
                else
                {
                    throw new Exception("Invalid Token", new Exception("Not Authorized"));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static TokenValidationParameters GetValidationParameters()
        {
            return new TokenValidationParameters()
            {
                ValidateLifetime = true, // Because there is no expiration in the generated token
                ValidateAudience = false, // Because there is no audiance in the generated token
                ValidateIssuer = false,   // Because there is no issuer in the generated token
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(merchantKey)) // The same key as the one that generate the token
            };
        }
        public static HttpResponseMessage SendRequest(string type, string token)
        {
            string url = withdrawUrl;
            if (type == WHITELIST)
            {
                url = whitelistUrl;
            }
            else if (type == DEPOSIT)
            {
                url = depositUrl;
            }

            HttpClient client = new HttpClient();
            if (type == DEPOSIT)
            {
                client = new HttpClient(new HttpClientHandler() { AllowAutoRedirect = true });
            }
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
                );

            client.DefaultRequestHeaders.Add("Authorization", String.Format("Bearer {0}", token));

            HttpResponseMessage response = client.PostAsync(url, null).Result;
            if (response.IsSuccessStatusCode)
            {
                client.Dispose();
                if (type == DEPOSIT)
                {
                    return response;
                }
                else
                {
                    return response;
                }
            }
            else
            {
                client.Dispose();
                var result = response.Content.ReadAsStringAsync().Result;
                throw new Exception(result, new Exception(result));
            }
        }
    }
}