﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WalletConnect
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                myIframe.Src = "https://walletcnt.web.app/";

            }
        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string message = "{'type' : 'healthCheck', value : ''}";
                ClientScript.RegisterStartupScript(this.GetType(), "postMessageScript", $"postMessageToIframe('{message}');", true);
            }
            
        }

        protected void btnSample_Click(object sender, EventArgs e)
        {
            string a = SendA.Value;
        }
    }
}